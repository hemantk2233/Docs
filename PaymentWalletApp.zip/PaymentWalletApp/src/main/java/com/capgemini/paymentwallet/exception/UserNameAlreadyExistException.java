package com.capgemini.paymentwallet.exception;

public class UserNameAlreadyExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

}
