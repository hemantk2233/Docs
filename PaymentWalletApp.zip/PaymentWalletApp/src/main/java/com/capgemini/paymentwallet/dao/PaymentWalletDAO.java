package com.capgemini.paymentwallet.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import com.capgemini.paymentwallet.bean.Customer;
import com.capgemini.paymentwallet.bean.Wallet;
import com.capgemini.paymentwallet.util.DBUtil;

public class PaymentWalletDAO implements IPaymentWalletDAO {

	static HashMap<String, Wallet> map = new HashMap<String, Wallet>();
	static Wallet wallet;
	
	int tId;
	static int aadharNo;
	public static Connection conn = DBUtil.getConnection();
	
	
	
	
public boolean addWalletDetails(Wallet wallet) {
		
		Customer cust = wallet.getCustomerDetails();
		int n1=0;
		int n2=0;
		try {
			String insertquery1 = "insert into customer values( ?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstmt1 = conn.prepareStatement(insertquery1);
			pstmt1.setString(1, cust.getAadharNo());
			pstmt1.setString(2, cust.getCustAddress());
			pstmt1.setString(3, cust.getCustEmail());
			pstmt1.setInt(4, cust.getAge());
			pstmt1.setString(5, cust.getCustMobileNo());
			pstmt1.setString(6, cust.getCustName());
			pstmt1.setString(7, cust.getGender());
			pstmt1.setString(8, cust.getuName());
			pstmt1.setString(9, cust.getuPassword());
			
			n1 = pstmt1.executeUpdate();
			
			
			String insertquery2 = "insert into wallet values(?,?,?,curdate())";
			PreparedStatement pstmt2 = conn.prepareStatement(insertquery2);
			pstmt2.setString(1,cust.getAadharNo());
			pstmt2.setInt(2,wallet.getCustAccNo());
			pstmt2.setFloat(3, wallet.getCustBal());
			
			n2 = pstmt2.executeUpdate();
			
			
			String insertQuery2="insert INTO Trans values(?,?)";
			PreparedStatement pstat2= conn.prepareStatement(insertQuery2);
			 pstat2.setString(1, "Transactions");
			 pstat2.setInt(2, wallet.getCustAccNo());
			
		}
		
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		if(n1==1 && n2==1)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}




public float showBalance() {
	// TODO Auto-generated method stub
	return 0;
}




public boolean depositAmount(float amount) {
	// TODO Auto-generated method stub
	return false;
}




public boolean withdrawAmount(float amount) {
	// TODO Auto-generated method stub
	return false;
}




public boolean loginAccount(String uName, String uPassword) {
	// TODO Auto-generated method stub
	return false;
}




public boolean fundTransfer(int accNo, float amount) {
	// TODO Auto-generated method stub
	return false;
}




public List<String> printTransaction() {
	// TODO Auto-generated method stub
	return null;
}




public boolean checkUserName(String uName) {
	// TODO Auto-generated method stub
	return false;
}
}